This dataset was provided by University of Torino for an EVALITA Campaign.

Link to the EVALITA Task: http://www.di.unito.it/~tutreeb/haspeede-evalita20/index.html

Link to original Data Download: https://live.european-language-grid.eu/catalogue/corpus/7498/download/

Licence

Creative Commons Attribution Non Commercial Share Alike 4.0 International
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode
https://creativecommons.org/licenses/by-nc-sa/4.0/
https://spdx.org/licenses/CC-BY-NC-SA-4.0.html
